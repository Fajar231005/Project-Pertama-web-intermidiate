import L from "leaflet";
import "leaflet/dist/leaflet.css";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";


delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

export default class HomePage {
  async render() {
    return `
      <section class="container">
        <h1>Home Page</h1>
        <h2>Lokasi Cerita Pengguna</h2>
        <div id="map" style="height: 500px; border-radius: 10px; margin-top: 1rem;"></div>
      </section>
    `;
  }

  async afterRender() {
    // Inisialisasi map di tengah Indonesia
    const map = L.map("map").setView([-2.5, 118], 5);

    
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
    }).addTo(map);

    // Ambil token login dari localStorage
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Silakan login terlebih dahulu!");
      window.location.hash = "/login";
      return;
    }

    // Ambil data stories dengan lokasi
    try {
      const response = await fetch(
        "https://story-api.dicoding.dev/v1/stories?location=1",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const result = await response.json();

      if (result.error) {
        alert(result.message);
        return;
      }

      const markers = [];

      result.listStory.forEach((story) => {
        if (story.lat && story.lon) {
          const marker = L.marker([story.lat, story.lon]).addTo(map);
          marker.bindPopup(
            `
            <div style="text-align:left;">
              <strong>${story.name}</strong><br>
              ${story.description}<br>
              <img src="${story.photoUrl}" alt="${story.name}" width="100" style="border-radius:6px;margin-top:5px;">
            </div>
          `,
            { maxWidth: 200 }
          );
          markers.push(marker);
        }
      });

      // Zoom map otomatis 
      if (markers.length) {
        const group = L.featureGroup(markers);
        map.fitBounds(group.getBounds().pad(0.2));
      }
    } catch (err) {
      console.error("Gagal memuat data lokasi:", err);
      alert("Gagal memuat data lokasi. Cek console untuk detail.");
    }
  }
}
