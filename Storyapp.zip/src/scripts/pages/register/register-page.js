class RegisterPage {
  async render() {
    return `
      <section class="page register-page">
        <h2>Daftar Akun Baru</h2>
        <form id="registerForm">
          <label for="name">Nama</label>
          <input id="name" type="text" name="name" required />

          <label for="email">Email</label>
          <input id="email" type="email" name="email" required />

          <label for="password">Password</label>
          <input id="password" type="password" name="password" required />

          <button type="submit">Daftar</button>
        </form>

        <p class="login-link">
        Sudah punya akun? <a href="#/login">Masuk di sini</a>
      </p>
      </section>
    `;
  }

  async afterRender() {
    const form = document.querySelector("#registerForm");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const name = form.name.value;
      const email = form.email.value;
      const password = form.password.value;

      const response = await fetch(
        "https://story-api.dicoding.dev/v1/register",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, password }),
        }
      );

      const result = await response.json();

      if (result.error) {
        alert(result.message);
      } else {
        alert("Registrasi berhasil! Silakan login.");
        window.location.hash = "/login";
      }
    });
  }
}

export default RegisterPage;
