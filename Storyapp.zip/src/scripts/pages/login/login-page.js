class LoginPage {
  async render() {
    return `
      <section class="page login-page">
        <h2>Masuk ke Akun</h2>
        <form id="loginForm">
          <label for="email">Email</label>
          <input id="email" type="email" name="email" required />
          
          <label for="password">Password</label>
          <input id="password" type="password" name="password" required />

          <button type="submit">Masuk</button>
        </form>

         <p class="register-redirect">
          Belum punya akun? 
          <a href="#/register">Daftar di sini</a>
        </p>

        <loading-indicator></loading-indicator>
        
      </section>
    `;
  }

  async afterRender() {
    const form = document.querySelector("#loginForm");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const email = form.email.value;
      const password = form.password.value;

      const response = await fetch("https://story-api.dicoding.dev/v1/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const result = await response.json();

      if (result.error) {
        alert(result.message);
      } else {
        localStorage.setItem("token", result.loginResult.token);
        alert("Login berhasil!");
        window.location.hash = "/";
      }
    });
  }
}

export default LoginPage;
