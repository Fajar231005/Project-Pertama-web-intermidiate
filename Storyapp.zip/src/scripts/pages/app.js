import routes from "../routes/routes";
import { getActiveRoute } from "../routes/url-parser";
import "../../styles/styles.css";

class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;
    this._setupDrawer();
  }

  _setupDrawer() {
    const overlay = document.getElementById("drawer-overlay");

    const toggleDrawer = () => {
      this.#navigationDrawer.classList.toggle("open");
      overlay.classList.toggle("active");
    };

    this.#drawerButton.addEventListener("click", toggleDrawer);
    this.#drawerButton.addEventListener("touchstart", toggleDrawer);

    overlay.addEventListener("click", () => {
      this.#navigationDrawer.classList.remove("open");
      overlay.classList.remove("active");
    });

    this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        this.#navigationDrawer.classList.remove("open");
        overlay.classList.remove("active");
      });
    });

    const logoutLink = document.getElementById("logout-link");
    if (logoutLink) {
      logoutLink.addEventListener("click", (e) => {
        e.preventDefault();
        localStorage.removeItem("token");
        this.#navigationDrawer.classList.remove("open");
        overlay.classList.remove("active");
        window.location.hash = "/login";
      });
    }
  }

  async renderPage() {
    const routeName = getActiveRoute();
    const page = routes[routeName] || routes["/"];
    const token = localStorage.getItem("token");

    // Daftar route yang butuh login
    const protectedRoutes = ["/", "/add-story"];

    // Jika user belum login dan mengakses route yang dilindungi → redirect ke login
    if (!token && protectedRoutes.includes(routeName)) {
      alert("Silakan login terlebih dahulu!");
      window.location.hash = "/login";
      return;
    }

    // Jika user sudah login dan berada di login/register → redirect ke home
    if (token && (routeName === "/login" || routeName === "/register")) {
      window.location.hash = "/";
      return;
    }

    this.#content.classList.add("fade-out");

    setTimeout(async () => {
      this.#content.innerHTML = await page.render();
      await page.afterRender();

      this.#content.classList.remove("fade-out");
      this.#content.classList.add("fade-in");

      setTimeout(() => {
        this.#content.classList.remove("fade-in");
      }, 400);
    }, 300);
  }
}

export default App;
