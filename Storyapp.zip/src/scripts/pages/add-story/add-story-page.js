import L from "leaflet";
import "leaflet/dist/leaflet.css";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

// Setup icon Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

class AddStoryPage {
  async render() {
    return `
      <section class="page add-story-page">
        <h2>Tambah Cerita Baru</h2>
        <form id="addStoryForm">
          <label for="description">Deskripsi Cerita</label>
          <textarea id="description" required></textarea>

          <label>Ambil Foto dari Kamera</label>
          <video id="camera" autoplay playsinline style="border-radius:6px;"></video>
          <div class="camera-controls">
            <button type="button" id="start-camera">Mulai Kamera</button>
            <button type="button" id="take-photo">Ambil Foto</button>
            <button type="button" id="delete-photo">Hapus Foto</button>
          </div>
          <canvas id="photo-canvas" style="display:none;"></canvas>
          <img id="photo-preview" style="margin-top:10px; max-width:100%; border-radius:6px;" />

          <label for="photo">Atau Unggah Foto</label>
          <input id="photo" type="file" accept="image/*" />

          <label>Lokasi Cerita</label>
          <div id="map" style="height: 300px; border-radius: 10px; margin-bottom:1rem;"></div>
          <div class="coords-display">Lat: <span id="lat-display">-</span>, Lon: <span id="lon-display">-</span></div>
          <input type="hidden" id="lat" required />
          <input type="hidden" id="lon" required />

          <button type="submit">Kirim Cerita</button>
        </form>
      </section>
    `;
  }

  async afterRender() {
    // MAP INTERAKTIF
    const map = L.map("map").setView([-2.5, 118], 5);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(map);

    let marker;
    map.on("click", (e) => {
      const { lat, lng } = e.latlng;
      document.querySelector("#lat").value = lat;
      document.querySelector("#lon").value = lng;
      document.querySelector("#lat-display").textContent = lat.toFixed(5);
      document.querySelector("#lon-display").textContent = lng.toFixed(5);

      if (marker) marker.setLatLng(e.latlng);
      else marker = L.marker(e.latlng).addTo(map);
    });

    // kamera dan foto
    const startCameraBtn = document.querySelector("#start-camera");
    const takePhotoBtn = document.querySelector("#take-photo");
    const deletePhotoBtn = document.querySelector("#delete-photo");
    const video = document.querySelector("#camera");
    const canvas = document.querySelector("#photo-canvas");
    const photoPreview = document.querySelector("#photo-preview");
    let stream;

    startCameraBtn.addEventListener("click", async () => {
      if (stream) return;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
        // Sembunyikan input file ketika kamera aktif
        document.querySelector("#photo").style.display = "none";
      } catch (err) {
        alert("Gagal mengakses kamera: " + err.message);
      }
    });

    takePhotoBtn.addEventListener("click", () => {
      if (!stream) return alert("Mulai kamera terlebih dahulu!");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0);
      // tampilkan preview
      photoPreview.src = canvas.toDataURL("image/png");
    });

    // hapus foto
    deletePhotoBtn.addEventListener("click", () => {
      photoPreview.src = "";
      canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
      // Tampilkan kembali input file
      document.querySelector("#photo").style.display = "block";
    });

    // submit form
    const form = document.querySelector("#addStoryForm");
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const description = document.querySelector("#description").value;
      const lat = document.querySelector("#lat").value;
      const lon = document.querySelector("#lon").value;

      if (!lat || !lon) {
        alert("Silakan pilih lokasi di peta!");
        return;
      }

      const token = localStorage.getItem("token");
      if (!token) {
        alert("Silakan login terlebih dahulu!");
        window.location.hash = "/login";
        return;
      }

      const formData = new FormData();
      formData.append("description", description);
      formData.append("lat", lat);
      formData.append("lon", lon);

      // prioritas dari kamera, kalau tidak ada ambil dari upload
      if (photoPreview.src && photoPreview.src.startsWith("data:image")) {
        const blob = await (await fetch(photoPreview.src)).blob();
        formData.append("photo", blob, "camera-photo.png");
      } else {
        const fileInput = document.querySelector("#photo");
        if (fileInput.files[0]) formData.append("photo", fileInput.files[0]);
        else return alert("Harap pilih foto atau ambil dari kamera!");
      }

      try {
        const response = await fetch(
          "https://story-api.dicoding.dev/v1/stories",
          {
            method: "POST",
            headers: { Authorization: `Bearer ${token}` },
            body: formData,
          }
        );
        const result = await response.json();
        if (result.error) alert(result.message);
        else {
          alert("Cerita berhasil dikirim!");
          window.location.hash = "/";
        }
      } catch (err) {
        console.error(err);
        alert("Terjadi kesalahan saat mengirim cerita.");
      }
    });
  }
}

export default AddStoryPage;
