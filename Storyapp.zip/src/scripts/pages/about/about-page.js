export default class AboutPage {
  async render() {
    return `
      <section class="page about-page container">
        <h1>Tentang Aplikasi Berbagi Cerita</h1>
        <p>Berbagi Cerita adalah aplikasi untuk membagikan pengalaman dan cerita secara online.</p>

        <h2>Fitur Utama</h2>
        <ul>
          <li>Melihat cerita pengguna lain di peta digital dengan marker dan popup.</li>
          <li>Menambahkan cerita baru dengan foto dan deskripsi.</li>
          <li>Login dan register untuk mengelola cerita.</li>
          <li>Transisi halaman SPA yang mulus.</li>
        </ul>

        <h2>Cara Menggunakan</h2>
        <ol>
          <li>Login atau daftar terlebih dahulu.</li>
          <li>Klik “Tambah Cerita” untuk mengunggah cerita baru.</li>
          <li>Lihat cerita lain di halaman Beranda atau peta interaktif.</li>
        </ol>

        <h2>Preview Cerita Terbaru</h2>
        <div id="latest-stories" class="preview-stories grid-container">
          <!-- Dummy stories sebelum login -->
          <div class="story-card">
            <img src="https://picsum.photos/200/150?random=1" alt="Cerita Contoh 1" />
            <h3>Nama Pengguna 1</h3>
            <p>Deskripsi cerita singkat...</p>
          </div>
          <div class="story-card">
            <img src="https://picsum.photos/200/150?random=2" alt="Cerita Contoh 2" />
            <h3>Nama Pengguna 2</h3>
            <p>Deskripsi cerita singkat...</p>
          </div>
           <div class="story-card">
            <img src="https://picsum.photos/200/150?random=3" alt="Cerita Contoh 2" />
            <h3>Nama Pengguna 2</h3>
            <p>Deskripsi cerita singkat...</p>
          </div>
          <div class="story-card">
            <img src="https://picsum.photos/200/150?random=4" alt="Cerita Contoh 2" />
            <h3>Nama Pengguna 2</h3>
            <p>Deskripsi cerita singkat...</p>
          </div>
          
        </div>

      </section>
    `;
  }

  async afterRender() {
    const container = document.getElementById("latest-stories");
    const token = localStorage.getItem("token");

    if (!token) {
      const info = document.createElement("p");
      info.textContent =
        "Login untuk melihat cerita terbaru dari pengguna lain.";
      info.style.fontStyle = "italic";
      container.prepend(info);
      return;
    }

    try {
      const response = await fetch(
        "https://story-api.dicoding.dev/v1/stories",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const result = await response.json();

      if (result.error) {
        container.innerHTML = `<p>${result.message}</p>`;
        return;
      }

      if (!result.listStory.length) {
        container.innerHTML = `<p>Belum ada cerita terbaru.</p>`;
        return;
      }

      // Tampilkan preview cerita nyata
      container.innerHTML = result.listStory
        .map(
          (story) => `
          <div class="story-card">
            <img src="${story.photoUrl}" alt="${story.name}" />
            <h3>${story.name}</h3>
            <p>${story.description.substring(0, 100)}${
            story.description.length > 100 ? "..." : ""
          }</p>
          </div>
        `
        )
        .join("");
    } catch (err) {
      console.error("Gagal memuat cerita:", err);
      container.innerHTML = `<p>Gagal memuat cerita terbaru. Cek console untuk detail.</p>`;
    }
  }
}
